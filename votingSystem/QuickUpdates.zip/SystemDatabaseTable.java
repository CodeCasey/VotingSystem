/**
 * 
 */
package votingSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/**
 * @author
 *
 */
public class SystemDatabaseTable {
	private String username;
	private String password;
	private String serverName;
	private int portNumber;
	private String databaseName;
	private String tableName;
	private Connection connection;
	/**
	 * Constructor of the SystemDatabaseTable.
	 * @param username
	 * @param password
	 * @param serverName
	 * @param portNumber
	 * @param databaseName
	 * @param tableName
	 * @param tableParams
	 */
	public SystemDatabaseTable(String username, String password, String serverName, int portNumber, String databaseName, String tableName, 
			String tableParams, Connection connection)
	{
		this.username = username;
		this.password = password;
		this.serverName = serverName;
		this.portNumber = portNumber;
		this.databaseName = databaseName;
		this.tableName = tableName;
		
		this.connection = connection;
		
		//execute command to create table
		createTable(this.connection, tableName, tableParams);
	}
	/**
	 * 
	 */
	public boolean equals(String tableName)
	{
		return this.tableName.equals(tableName);
	}
	/**
	 * 
	 * @param table
	 * @return
	 */
	public boolean equals(SystemDatabaseTable table)
	{
		String tableName = table.getName();
		return tableName.equals(this.tableName);
	}
	/**
	 * 
	 * @param conn
	 * @param tableName
	 * @param tableParams
	 * @return
	 */
	public boolean createTable(Connection conn, String tableName, String tableParams)
	{
		try {
			return executeUpdate(conn, "create table " + tableName + " " + tableParams);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean drop()
	{
		try {
		    String dropString = "DROP TABLE " + this.tableName;
			this.executeUpdate(this.connection, dropString);
			System.out.println("Dropped the table");
			return true;
	    } catch (SQLException e) {
			System.out.println("ERROR: Could not drop the table");
			e.printStackTrace();
			return false;
		}
	}
	/**
	 * 
	 * @param conn
	 * @param command
	 * @return
	 * @throws SQLException
	 */
	private boolean executeUpdate(Connection conn, String command) throws SQLException {
	    Statement stmt = null;
	    try {
	        stmt = conn.createStatement();
	        stmt.executeUpdate(command); // This will throw a SQLException if it fails
	        return true;
	    } finally {

	    	// This will run whether we throw an exception or not
	        if (stmt != null) { stmt.close(); }
	    }
	}
	/**
	 * Method for calling commands.
	 * @param command
	 * @return
	 * @throws SQLException
	 */
	public boolean executeUpdate(String command) throws SQLException {
	    return executeUpdate(this.connection, command);
	}
	
	public String getName()
	{
		return tableName;
	}
	/**
	 * Gets the ResultSet of a Query.
	 * @param columnNames The name(s) of the column (ex: *, fname, etc.)
	 * @return The ResultSet of the query
	 */
	public ResultSet getResultSet(String columnNames)
	{
		Statement stmt;
		String query = "select " + columnNames + " from " + this.tableName;
		//System.out.printf("Performing query: %s\n\n", query);
		try {
			stmt = this.connection.createStatement();
			return stmt.executeQuery(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * Gets the ResultSet of a Query.
	 * Acts as a more specialized version of executeQuery
	 * @param columnNames The name(s) of the column (ex: *, fname, etc.)
	 * @param constraints The constraint(s) of a query (ex: id = 5, fname = donald, etc.)
	 * @return The ResultSet of the query
	 */
	public ResultSet getResultSet(String columnNames, String constraints)
	{
		String query = "select " + columnNames + " from " + this.tableName 
				+ " where " + constraints;
		//System.out.printf("Performing query: %s\n\n", query);
		return executeQuery(createStatement(), query);
	}
	/**
	 * Creates a result set based on a query.
	 * @param statement The statement to be used
	 * @param query The query to be used
	 * @return A ResultSet based on the query, or null if it failed
	 */
	public ResultSet executeQuery(Statement statement, String query)
	{
		try {
			return statement.executeQuery(query);
		} catch (SQLException e) {
			System.out.println("FAILED TO EXECUTE QUERY!");
			e.printStackTrace();
			return null;
		}
	}
	/**
	 * Creates a statement.
	 * @return
	 */
	public Statement createStatement()
	{
		try {
			return this.connection.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("FAILED TO CREATED STATEMENT!");
			e.printStackTrace();
			return null;
		}
	}
	/**
	 * 
	 * @param resultSetType
	 * @param resultSetConcurrency
	 * @return
	 */
	public Statement createStatement(int resultSetType, int resultSetConcurrency)
	{
		try {
			return this.connection.createStatement(resultSetType, resultSetConcurrency);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("FAILED TO CREATED STATEMENT!");
			e.printStackTrace();
			return null;
		}
	}
	/**
	 * 
	 * @param resultSetType
	 * @param resultSetConcurrency
	 * @param resultSetHoldability
	 * @return
	 */
	public Statement createStatement(int resultSetType, int resultSetConcurrency, 
			int resultSetHoldability)
	{
		try {
			return this.connection.createStatement(resultSetType, resultSetConcurrency, 
					resultSetHoldability);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("FAILED TO CREATED STATEMENT!");
			e.printStackTrace();
			return null;
		}
	}
	/**
	 * Changes the username.
	 * @param username The new username
	 */
	public void setUsername(String username) {
		this.username = username;
		
	}
	/**
	 * Changes the password.
	 * @param password The new password
	 */
	public void setPassword(String password) {
		this.password = password;
		
	}
	/**
	 * Changes the database name.
	 * @param databaseName The new database name
	 */
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
		
	}
	/**
	 * Changes the port number.
	 * @param portNumber The new port number
	 */
	public void setPortNumber(int portNumber) {
		this.portNumber = portNumber;
		
	}
	/**
	 * Changes the server name.
	 * @param serverName The new server name
	 */
	public void setServerName(String serverName) {
		this.serverName = serverName;
		
	}
	/**
	 * Changes the connection.
	 * @param connection The new connection
	 */
	public void setConnection(Connection connection) {
		this.connection = connection;
	}
	

}
