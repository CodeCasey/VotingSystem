/**
 * 
 */
package votingSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

/**
 * @author spens
 *
 */
public class SystemDatabase {
	private ArrayList<SystemDatabaseTable> tables;
	//following 3 ints work under assumption that tables have been added in this order
	private static final int VOTER_TABLE_INDEX = 0;
	private static final int ADMINISTRATOR_TABLE_INDEX = 1;
	private static final int RESULTS_TABLE_INDEX = 2;
	
	public static final int VOTER_VALID = 0x10; //found in table
	public static final int VOTER_INVALID = 0x11; //not found in table
	public static final int VOTER_HAS_VOTED = 0x12; //already voted
	public static final int VOTER_CHECK_FAILURE = 0x13; //Failed to check
	
	
	private String username;
	private String password;
	private String serverName;
	private int portNumber;
	private String databaseName;
	private boolean createDatabaseSuccess;
	private Connection connection;
	/**
	 * Creates the database.
	 * @param username
	 * @param password
	 * @param serverName
	 * @param portNumber
	 * @param databaseName
	 */
	public SystemDatabase(String username, String password, String serverName, int portNumber, String databaseName)
	{
		this.username = username;
		this.password = password;
		this.serverName = serverName;
		this.portNumber = portNumber;
		this.databaseName = databaseName;
		//this.createDatabaseSuccess = createDatabase(); //database needs to be created to execute command, command creates duplicate database
		this.tables = new ArrayList<SystemDatabaseTable>();
		try {
			this.connection = createConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("FAILED TO CREATE CONNECTION!\nDATABASE WILL NOT FUNCTION PROPERLY!");
			e.printStackTrace();
		}
		useDatabase();
	}
	/**
	 * Adds a table to the database.
	 * @param tableName Name of table to be added
	 */
	public int addTable(String tableName, String tableParams)
	{
		for (int i = 0; i < tables.size(); i++)
		{
			SystemDatabaseTable table = tables.get(i);
			if (table.equals(tableName))
			{
				System.out.printf("Table %s already exists!", tableName);
				return tables.size();
			}
		}
		SystemDatabaseTable dbTable = new SystemDatabaseTable(this.username, this.password, this.serverName, this.portNumber, 
				this.databaseName, tableName, tableParams, this.connection);
                //add table to ArrayList<>
                    tables.add(dbTable);
                    return tables.size() - 1;
                
	}
	/**
	 * Creates a new database connection
	 * 
	 * @return
	 * @throws SQLException
	 */
	private Connection createConnection() throws SQLException {
		Connection conn = null;
		Properties connectionProps = new Properties();
		connectionProps.put("user", this.username);
		connectionProps.put("password", this.password);

		conn = DriverManager.getConnection("jdbc:mysql://"
				+ this.serverName + ":" + this.portNumber + "/" + this.databaseName,
				connectionProps);

		return conn;
	}
	/**
	 * Switches use to this database.
	 * @return True if successful
	 */
	public boolean useDatabase()
	{

		Connection conn = null;
		Properties connectionProps = new Properties();
		connectionProps.put("user", this.username);
		connectionProps.put("password", this.password);
		String command = "use " + databaseName;

		
		Statement stmt = null;
	    try 
	    {
	    	conn = DriverManager.getConnection("jdbc:mysql://"
					+ this.serverName + ":" + this.portNumber + "/" + this.databaseName,
					connectionProps);
	        stmt = conn.createStatement();
	        stmt.executeUpdate(command); // This will throw a SQLException if it fails 
	        if (stmt != null) { stmt.close(); }
	        return true;
	    } catch (SQLException e) 
	    {
	    	System.out.printf("\n\n***************** ERROR: Failed to use database!\n used command: %s\n **************************************", command);
	    	e.printStackTrace();
	    	return false;
	    }
	}
	/**
	 * Determines whether the database is valid.
	 * Database is valid if it was successfully created.
	 * @return True if database is valid, false otherwise
	 */
	public boolean databaseValid()
	{
		return this.createDatabaseSuccess;
	}
	/**
	 * Drops all the tables in a database.
	 * @return True if the operation was successful, false otherwise
	 */
	public boolean dropTables()
	{
		while(!tables.isEmpty())
			(tables.remove(0)).drop();
		return true;
	}
	/**
	 * Returns the list of tables.
	 * @return An ArrayList containing the tables
	 */
	public ArrayList<SystemDatabaseTable> getTableList()
	{
		return tables;
	}
	/**
	 * Returns a table based on its name.
	 * @param tableName The name of the table
	 * @return The requested table or null if the table is invalid
	 */
	public SystemDatabaseTable getTable(String tableName)
	{
		for (int i = 0; i < tables.size(); i++)
		{
			SystemDatabaseTable sdt = tables.get(i);
			if (sdt.equals(tableName))
				return sdt;
		}
		return null;
	}
	/**
	 * Gets a table based on its index.
	 * @param index The index of the table
	 * @return A table or a null pointer if the index value was invalid
	 */
	public SystemDatabaseTable getTable(int index)
	{
		if (index < 0 || index >= tables.size())
			return null;
		return tables.get(index);
	}
        
    public boolean exists(String tableName) {
            
           int size = tables.size();
           int i = 0;
           while(size < tables.size()) {
               
                if(tables.get(i).equals(tableName)) {
                    return false;
                }
           }
             return true;  
        }
    /**
     * Checks if a voter is valid or not. Returns an int signifying this.
     * Example check: if (checkVoterValidity(3) == SystemDatabase.VOTER_VALID) allowVoting();
     * @param id The ID value of the voter
     * @return An int signifying the results
     */
    public int checkVoterValidity(String id)
    {
    	SystemDatabaseTable voters = tables.get(SystemDatabase.VOTER_TABLE_INDEX);
    	ResultSet rs = voters.getResultSet("hasVoted", "id = \"" + id + "\"");
    	try {
			if (!rs.next())
				return SystemDatabase.VOTER_INVALID;
			if (rs.getInt("hasVoted") != 0)
	    		return SystemDatabase.VOTER_HAS_VOTED;
	    	return SystemDatabase.VOTER_VALID;
		} catch (SQLException e) {
			System.out.println("FAILED TO VALIDATE VOTER!");
			e.printStackTrace();
		}
    	return SystemDatabase.VOTER_CHECK_FAILURE;
    }
    
    /**
     * Checks if a voter is valid or not. Returns an int signifying this.
     * Fake method to test previous method.
     * Example check: if (checkVoterValidity(3) == SystemDatabase.VOTER_VALID) allowVoting();
     * @param id The ID value of the voter
     * @return An int signifying the results
     */
    private int dummyCheckVoterValidity(String id)
    {
    	SystemDatabaseTable voters = tables.get(SystemDatabase.VOTER_TABLE_INDEX);
    	ResultSet rs = voters.getResultSet("fname", "id = \"" + id + "\"");
    	try {
			if (rs == null || !rs.next())
				return SystemDatabase.VOTER_INVALID;
			if (!rs.getString("fname").equals("James"))
	    		return SystemDatabase.VOTER_HAS_VOTED;
	    	return SystemDatabase.VOTER_VALID;
		} catch (SQLException e) {
			System.out.println("FAILED TO VALIDATE VOTER!");
			e.printStackTrace();
		}
    	return SystemDatabase.VOTER_CHECK_FAILURE;
    }
    /**
     * Tests if checking for voter validity works properly.
     */
    public void testCheck()
    {
    	System.out.printf("Testing voter not found: ");
    	if (dummyCheckVoterValidity("5048451427 whatever") == SystemDatabase.VOTER_INVALID)
    		System.out.println("SUCCESS!");
    	else
    		System.out.println("FAILED :(");
    	System.out.printf("Testing voter found but not valid: ");
    	if (dummyCheckVoterValidity("8103749840") == SystemDatabase.VOTER_HAS_VOTED)
    		System.out.println("SUCCESS! voter is not James");
    	else
    		System.out.println("Failed, voter is James");
    	System.out.printf("Testing voter OK: ");
    	if (dummyCheckVoterValidity("5048451427") == SystemDatabase.VOTER_VALID)
    		System.out.println("SUCCESS!");
    	else
    		System.out.println("This is SQL\'s fault");
    }
    /**
     * Changes the username.
     * @param username The new username
     */
    private void setUsername(String username)
    {
    	this.username = username;
    	for (int i = 0; i < tables.size(); i++)
    		(tables.get(i)).setUsername(username);
    }
    public void resetUsername(String username)
    {
    	setUsername(username);
    	resetConnection();
    }
    /**
     * Changes the password.
     * @param password The new password
     */
    private void setPassword(String password)
    {
    	this.password = password;
    	for (int i = 0; i < tables.size(); i++)
    		(tables.get(i)).setPassword(password);
    }
    /**
     * Resets the password.
     * @param password The new password
     */
    public void resetPassword(String password)
    {
    	setPassword(password);
    	resetConnection();
    }
	/**
	 * Changes the server name.
	 * @param serverName The new server name
	 */
    private void setServerName(String serverName)
    {
    	this.serverName = serverName;
    	for (int i = 0; i < tables.size(); i++)
    		(tables.get(i)).setServerName(serverName);
    }
    /**
     * Resets the server name.
     * @param serverName The new server name
     */
    public void resetServerName(String serverName)
    {
    	setServerName(serverName);
    	resetConnection();
    }
	/**
	 * Changes the port number.
	 * @param portNumber The new port number
	 */
    private void setPortNumber(int portNumber)
    {
    	this.portNumber = portNumber;
    	for (int i = 0; i < tables.size(); i++)
    		(tables.get(i)).setPortNumber(portNumber);
    }
    /**
     * Resets the port number.
     * @param portNumber The new port number
     */
    public void resetPortNumber(int portNumber)
    {
    	setPortNumber(portNumber);
    	resetConnection();
    }
	/**
	 * Changes the database name;
	 * @param databaseName The name of the new database
	 */
    private void setDatabaseName(String databaseName)
    {
    	this.databaseName = databaseName;
    	for (int i = 0; i < tables.size(); i++)
    		(tables.get(i)).setDatabaseName(databaseName);
    }
    /**
     * Resets the database name.
     * @param databaseName The new database name
     */
    public void resetDatabaseName(String databaseName)
    {
    	setDatabaseName(databaseName);
    	resetConnection();
    }
	/**
	 * Resets the connection.
	 * Useful if information such as username or port number has changed.
	 */
	public void resetConnection()
	{
		try {
			this.connection = createConnection();
			for (int i = 0; i < tables.size(); i++)
				(tables.get(i)).setConnection(this.connection);
		} catch (SQLException e) {
			System.out.println("FAILED TO RESET CONNECTION!");
			e.printStackTrace();
		}
	}
	/**
	 * Moves to a new database.
	 * Useful for accessing backup databases.
	 * This works under the assumption that the backup has the same table names.
	 * @param username The username of the database
	 * @param password The password of the database
	 * @param serverName The server name of the database
	 * @param portNumber The port number of the database
	 * @param DatabaseName The name of the database
	 */
	public void migrateDatabase(String username, String password, String serverName, 
			int portNumber, String databaseName)
	{
		setUsername(username);
		setPassword(password);
		setServerName(serverName);
		setPortNumber(portNumber);
		setDatabaseName(databaseName);
		resetConnection();
	}
}
